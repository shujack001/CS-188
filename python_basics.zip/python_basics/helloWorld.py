# Comment: This is a fairly simple Python script

print('Hello, World!')
